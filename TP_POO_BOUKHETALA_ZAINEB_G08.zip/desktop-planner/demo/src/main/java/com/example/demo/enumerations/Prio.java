package com.example.demo.enumerations;

import java.io.Serializable;

public enum Prio implements Serializable {
    LOW, MEDIUM, HIGH
}
