package com.example.demo.planification;

import java.io.Serializable;

public interface Decomposable  {
    // public void decomposer(int decompo);
}
